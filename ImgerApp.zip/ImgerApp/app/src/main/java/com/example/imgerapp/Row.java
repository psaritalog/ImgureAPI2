package com.example.imgerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Row extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_row);
    }
}